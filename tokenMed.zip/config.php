<?php
/**
 * config.php — Database credentials ONLY.
 * ALL other configuration lives in the `settings` table.
 * Do NOT add any business logic or hardcoded values here.
 */

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'token_med');

/**
 * Absolute filesystem path to the project root (no trailing slash).
 * Used for require/include paths throughout the app.
 */

define('BASE_PATH', rtrim(__DIR__, '/'));

/**
 * Public URL of the application (no trailing slash).
 * Change this to your domain / subdirectory.
 */
define('BASE_URL', 'http://localhost/tokenmed');
